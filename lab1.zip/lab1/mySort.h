#ifndef MYSORT_H
#define MYSORT_H

void mySort(int array[], unsigned int num_elements);

#endif